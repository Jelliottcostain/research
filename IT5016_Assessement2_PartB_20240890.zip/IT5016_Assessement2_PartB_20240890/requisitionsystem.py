from datetime import date


class RequisitionSystem:
    def __init__(self, date, staffID, staffName, status):
        self.date = date
        self.staffID = staffID
        self.staffName = staffName
        self.status = status

# This allows staff members to input their information about themselves.
    def staff_info(self):
        global date, staffID, staffName, req_num, new_req, req
        new_req += 1
        date = date.today()
        staffID = str(input('Enter your staff ID number: '))
        staffName = str(input('Enter your name: '))
        req_num = 10000 + new_req
        req = str(req_num)
        print('Printing Staff Information:')
        print(f'Date: {date}')
        print(f'Staff ID: {staffID}')
        print(f'Staff Member: {staffName}')
        print(f'Requisition Number: {req_num}')

# calculate the total of all items for requestion
    def requisition_total(self):
        global item_name, item_price, total
        key = 'y'
        total = 0
        while key == 'y':
            item_name = str(input('Item Name: '))
            item_price = float(input('Items Price: '))
            total += item_price
            print(f'Total: ${total}')
            key = str(input('Do you wish to request another item? y/n: '))

# Basic system that automate a little bit of the aprroval process by approving anything under 500
    def requisition_approval(self):
        global status
        status = 'Pending'
        if total <= 500:
            status = 'Approved'

# Displays the request from a staff member as well as any additional info about who when etc.    
    def display_requisition(self):
        global staffID, staffName, total, status
        print()
        print('Printing Requisitions:')
        print('------------------------')
        print(f'Date: {date}')
        print(f'Staff ID: {staffID}')
        print(f'Staff Member: {staffName}')
        print(f'Total: ${total}')
        print(f'Status: {status}')
        print('------------------------')

# Prints all statistics gathered
    def requisition_statistic(self):
        global total_sub, approved, pending, declined
        print(f'Total amount of requisitions: {total_sub}')
        print(f'Total amount of approved requisitions: {approved}')
        print(f'Total amount of pending requisitions: {pending}')
        print(f'Total amount of declined requisitions: {declined}')

# Allows manager to respond to requests aswell as counting statistics.
    def respond_requisition(self):
        global status, approved, pending, declined, total_sub
        loop = True
        #check if over 500 for manual approval
        if total >= 500:
            while loop == True:
                status_new = input('Apply new status: Approve/Decline/Pending : ')
                if status_new == 'Approve':
                    status = 'Approved'
                    loop = False
                elif status_new == 'Decline':
                    status = 'Declined'
                    loop = False
                elif status_new == 'Pending':
                    status = 'Pending'
                    loop = False
                else:
                    print('Invalid')
                    loop = True
        #stats counter
        total_sub += 1
        if status == 'Approved':
            approved += 1
        elif status == 'Declined':
            declined += 1
        if status == 'Pending':
            pending += 1

# Counters for requests and statistic basic counters.
approved = 0
total_sub = 0
pending = 0
declined = 0
new_req = 0
xx = True
a1 = RequisitionSystem(date, '','','')
#Loop for gathering information and reacting to it. Basically the main that runs everything.
while xx == True:
    a1.staff_info()
    print()
    a1.requisition_total()
    print()
    a1.requisition_approval()
    print()
    a1.display_requisition()
    print()
    a1.respond_requisition()
    print()
    a1.display_requisition()
    print()
    a1.requisition_statistic()
    print()
    query = input('Another? True/False: ')
    if query == 'False':
        xx = False
    else:
        xx = True
    