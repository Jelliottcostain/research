"""
author: Jacob Elliott-Costain
program overview: Program for purchase requisition and approval.
"""

from datetime import date

# Staff Information Form Function
def staff_info():
    global date_cur, staff_id, staff_name, req_num, new_req, req
    new_req += 1
    date_cur = date.today()
    staff_id = str(input('Enter your staff ID number: '))
    staff_name = str(input('Enter your name: '))
    req_num = 10000 + new_req
    req = str(req_num)
    print('Printing Staff Information:')
    print(f'Date: {date_cur}')
    print(f'Staff ID: {staff_id}')
    print(f'Staff Member: {staff_name}')
    print(f'Requisition Number: {req_num}')


# Requisition Total Function
def requisition_total():
    global item_name, item_price, total
    staff_info()
    key = 'y'
    total = 0
    while key == 'y':
        item_name = str(input('Item Name: '))
        item_price = float(input('Items Price: '))
        total += item_price
        print(f'Total: ${total}')
        key = str(input('Do you wish to request another item? y/n: '))
            



# Requisition Approval Function
def requisition_approval(x):
    global status
    status = 'Pending'
    if x <= 500:
        status = 'Approved'


# Displays the Requisition
def display_requisition():
    print()
    print('Printing Requisitions:')
    print('------------------------')
    print(f'Date: {date_cur}')
    print(f'Requisition ID: {req_num}')
    print(f'Staff ID: {staff_id}')
    print(f'Staff Member: {staff_name}')
    print(f'Total: ${total}')
    print(f'Status: {status}')
    print(f'Approval Reference Number: {staff_id}{req[len(req)-3:len(req)]}')
    print('------------------------')


# Requisition Number Counter
new_req = 0
# Main
requisition_total()
requisition_approval(total)
display_requisition()
    
   